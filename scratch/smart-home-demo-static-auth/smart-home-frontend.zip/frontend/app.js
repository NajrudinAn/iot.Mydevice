let authToken = null;
let streamAbortController = null;

// The platform injects these variables if this is hosted natively.
const PLATFORM_BASE_URL = window.PLATFORM_BASE_URL || 'http://localhost:3000';
const PLATFORM_APP_ID = window.PLATFORM_APP_ID || 'dummy-app-id';

// Placeholder API routes - configure these in the platform!
const ROUTES = {
    telemetry: '/api/v1/routes/smart-home-telemetry',
    commands: '/api/v1/routes/smart-home-commands'
};

const ui = {
    views: {
        auth: document.getElementById('auth-view'),
        dashboard: document.getElementById('dashboard-view')
    },
    login: {
        form: document.getElementById('login-form'),
        email: document.getElementById('email'),
        password: document.getElementById('password'),
        btn: document.getElementById('loginBtn'),
        error: document.getElementById('loginError')
    },
    dashboard: {
        temp: document.getElementById('temp-val'),
        hum: document.getElementById('hum-val'),
        lightToggle: document.getElementById('lightToggle'),
        fanSlider: document.getElementById('fanSlider'),
        fanIcon: document.getElementById('fan-icon'),
        status: document.getElementById('connection-status'),
        log: document.getElementById('event-log'),
        logoutBtn: document.getElementById('logoutBtn')
    }
};

function addLog(message, type = 'system') {
    const entry = document.createElement('div');
    entry.className = `log-entry ${type}`;
    const time = new Date().toLocaleTimeString();
    entry.textContent = `[${time}] ${message}`;
    ui.dashboard.log.appendChild(entry);
    ui.dashboard.log.scrollTop = ui.dashboard.log.scrollHeight;
}

function showView(viewName) {
    Object.values(ui.views).forEach(v => {
        v.classList.remove('active');
        setTimeout(() => v.classList.add('hidden'), 400); // Wait for fade out
    });
    
    const target = ui.views[viewName];
    target.classList.remove('hidden');
    // small delay to allow display:block to apply before animating opacity
    setTimeout(() => target.classList.add('active'), 50);
}

ui.login.form.addEventListener('submit', async (e) => {
    e.preventDefault();
    ui.login.btn.disabled = true;
    ui.login.btn.textContent = 'Authenticating...';
    ui.login.error.classList.add('hidden');

    try {
        const response = await fetch(`${PLATFORM_BASE_URL}/api/applications/${PLATFORM_APP_ID}/auth/login`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                email: ui.login.email.value,
                password: ui.login.password.value
            })
        });

        const data = await response.json();

        if (data.success) {
            authToken = data.token;
            showView('dashboard');
            startTelemetryStream();
        } else {
            ui.login.error.textContent = data.message || 'Login failed';
            ui.login.error.classList.remove('hidden');
        }
    } catch (err) {
        ui.login.error.textContent = 'Network error connecting to platform.';
        ui.login.error.classList.remove('hidden');
    } finally {
        ui.login.btn.disabled = false;
        ui.login.btn.textContent = 'Authenticate';
    }
});

ui.dashboard.logoutBtn.addEventListener('click', () => {
    if (streamAbortController) {
        streamAbortController.abort();
    }
    authToken = null;
    showView('auth');
    addLog('Logged out.', 'system');
});

async function startTelemetryStream() {
    ui.dashboard.status.textContent = 'Connecting...';
    ui.dashboard.status.className = 'status-badge connecting';
    
    if (streamAbortController) streamAbortController.abort();
    streamAbortController = new AbortController();

    try {
        const response = await fetch(`${PLATFORM_BASE_URL}${ROUTES.telemetry}`, {
            headers: { 
                'Authorization': `Bearer ${authToken}`,
                'Accept': 'text/event-stream'
            },
            signal: streamAbortController.signal
        });

        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }

        ui.dashboard.status.textContent = 'Connected';
        ui.dashboard.status.className = 'status-badge connected';
        addLog('Connected to Realtime Telemetry Stream', 'system');

        const reader = response.body.getReader();
        const decoder = new TextDecoder();
        let buffer = '';

        while (true) {
            const { value, done } = await reader.read();
            if (done) break;
            
            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n\n');
            buffer = lines.pop(); // Keep incomplete chunk

            for (const line of lines) {
                if (line.startsWith('data: ')) {
                    const dataStr = line.slice(6);
                    if (dataStr.trim() === 'heartbeat') continue;

                    try {
                        const data = JSON.parse(dataStr);
                        updateDashboard(data);
                    } catch (e) {
                        console.error('Error parsing SSE data', e);
                    }
                }
            }
        }
    } catch (err) {
        if (err.name === 'AbortError') return;
        ui.dashboard.status.textContent = 'Disconnected';
        ui.dashboard.status.className = 'status-badge error';
        addLog(`Stream error: ${err.message}`, 'error');
        
        // Auto-reconnect after 3 seconds
        setTimeout(startTelemetryStream, 3000);
    }
}

function updateDashboard(data) {
    if (!data.payload) return;
    
    // We expect telemetry mapped in payload
    const telemetry = data.payload;
    addLog(`Received telemetry update`, 'incoming');

    if (telemetry.temperature !== undefined) {
        ui.dashboard.temp.textContent = `${telemetry.temperature} °C`;
    }
    if (telemetry.humidity !== undefined) {
        ui.dashboard.hum.textContent = `${telemetry.humidity} %`;
    }
    
    // Don't update actuators if user is actively interacting (to prevent jitter)
    if (telemetry.light_status !== undefined && document.activeElement !== ui.dashboard.lightToggle) {
        ui.dashboard.lightToggle.checked = telemetry.light_status;
    }
    
    if (telemetry.fan_speed !== undefined && document.activeElement !== ui.dashboard.fanSlider) {
        ui.dashboard.fanSlider.value = telemetry.fan_speed;
        // visual rotation speed
        const speeds = [0, 1, 2, 4]; // rotations per second approximation
        const speed = speeds[telemetry.fan_speed];
        if (speed === 0) {
            ui.dashboard.fanIcon.style.animation = 'none';
        } else {
            ui.dashboard.fanIcon.style.animation = `spin ${1/speed}s linear infinite`;
        }
    }
}

// Add keyframes dynamically for the fan spin
const style = document.createElement('style');
style.innerHTML = `
@keyframes spin { 100% { transform: rotate(360deg); } }
`;
document.head.appendChild(style);

// Command Sending
async function sendCommand(command, payload) {
    addLog(`Sending command: ${command}`, 'outgoing');
    try {
        const response = await fetch(`${PLATFORM_BASE_URL}${ROUTES.commands}`, {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/json',
                'Authorization': `Bearer ${authToken}`
            },
            body: JSON.stringify({
                command: command,
                payload: payload
            })
        });
        
        const data = await response.json();
        if (data.success) {
            addLog(`Command successful`, 'system');
        } else {
            addLog(`Command failed: ${data.error?.message || 'Unknown error'}`, 'error');
        }
    } catch (err) {
        addLog(`Command network error`, 'error');
    }
}

ui.dashboard.lightToggle.addEventListener('change', (e) => {
    sendCommand('SET_LIGHT', { status: e.target.checked });
});

ui.dashboard.fanSlider.addEventListener('change', (e) => {
    sendCommand('SET_FAN_SPEED', { speed: parseInt(e.target.value, 10) });
});
